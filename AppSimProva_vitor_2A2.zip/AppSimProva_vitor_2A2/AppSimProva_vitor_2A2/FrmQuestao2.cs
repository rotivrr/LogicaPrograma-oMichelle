﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_vitor_2A2
{
    public partial class FrmQuestao2 : Form
    {
        public FrmQuestao2()
        {
            InitializeComponent();
        }
    }
}
