﻿namespace AppSimProva_vitor_2A2
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlGray = new System.Windows.Forms.Panel();
            this.lblExercicioP = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorDesconto = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlGray.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlGray
            // 
            this.pnlGray.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnlGray.Controls.Add(this.lblExercicioP);
            this.pnlGray.Location = new System.Drawing.Point(1, -7);
            this.pnlGray.Name = "pnlGray";
            this.pnlGray.Size = new System.Drawing.Size(768, 114);
            this.pnlGray.TabIndex = 0;
            // 
            // lblExercicioP
            // 
            this.lblExercicioP.AutoSize = true;
            this.lblExercicioP.Font = new System.Drawing.Font("Yu Gothic UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicioP.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblExercicioP.Location = new System.Drawing.Point(42, 35);
            this.lblExercicioP.Name = "lblExercicioP";
            this.lblExercicioP.Size = new System.Drawing.Size(315, 40);
            this.lblExercicioP.TabIndex = 0;
            this.lblExercicioP.Text = "Exercicio Porcentagem";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(12, 175);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(110, 15);
            this.lblValor.TabIndex = 1;
            this.lblValor.Text = "Valor Compra :";
            // 
            // txtValor
            // 
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValor.Location = new System.Drawing.Point(185, 161);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(159, 35);
            this.txtValor.TabIndex = 2;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Open Sans", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(15, 242);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(374, 46);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            // 
            // lblValorDesconto
            // 
            this.lblValorDesconto.AutoSize = true;
            this.lblValorDesconto.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDesconto.Location = new System.Drawing.Point(12, 349);
            this.lblValorDesconto.Name = "lblValorDesconto";
            this.lblValorDesconto.Size = new System.Drawing.Size(149, 15);
            this.lblValorDesconto.TabIndex = 4;
            this.lblValorDesconto.Text = "Valor com desconto :";
            this.lblValorDesconto.Click += new System.EventHandler(this.lblValorDesconto_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(236, 350);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(15, 20);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = "-";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 496);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblValorDesconto);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.pnlGray);
            this.Name = "FrmQuestao01";
            this.Text = "Form1";
            this.pnlGray.ResumeLayout(false);
            this.pnlGray.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlGray;
        private System.Windows.Forms.Label lblExercicioP;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValorDesconto;
        private System.Windows.Forms.Label lblResultado;
    }
}

