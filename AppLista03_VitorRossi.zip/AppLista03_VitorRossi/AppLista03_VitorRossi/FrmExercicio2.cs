﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_VitorRossi
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcl_Click(object sender, EventArgs e)
        {
            float varGas = float.Parse(txtGas.Text);
            float varpreco = float.Parse(txtPago.Text);
            float resultado = varpreco / varGas;
            MessageBox.Show("O usuário abasteceu " + resultado + " litros no total");
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
