﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_VitorRossi
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcl_Click(object sender, EventArgs e)
        {
            float pesoalimento = float.Parse(txtPeso.Text);
            float resultado = pesoalimento * 34;
            MessageBox.Show("O valor do quilo é " + resultado);

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPeso_Click(object sender, EventArgs e)
        {

        }
    }
}
