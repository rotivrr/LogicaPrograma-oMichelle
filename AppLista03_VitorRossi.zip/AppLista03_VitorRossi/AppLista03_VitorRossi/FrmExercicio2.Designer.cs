﻿namespace AppLista03_VitorRossi
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.txtGas = new System.Windows.Forms.TextBox();
            this.lblPago = new System.Windows.Forms.Label();
            this.lblPrecoGas = new System.Windows.Forms.Label();
            this.pnlCabecario = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlRodape = new System.Windows.Forms.Panel();
            this.pnlCabecario.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(300, 249);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(207, 59);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseCompatibleTextRendering = true;
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.UseWaitCursor = true;
            // 
            // txtPago
            // 
            this.txtPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPago.Location = new System.Drawing.Point(415, 188);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(143, 31);
            this.txtPago.TabIndex = 8;
            // 
            // txtGas
            // 
            this.txtGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGas.Location = new System.Drawing.Point(415, 111);
            this.txtGas.Name = "txtGas";
            this.txtGas.Size = new System.Drawing.Size(143, 31);
            this.txtGas.TabIndex = 7;
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPago.Location = new System.Drawing.Point(240, 185);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(144, 31);
            this.lblPago.TabIndex = 6;
            this.lblPago.Text = "Valor Pago:";
            // 
            // lblPrecoGas
            // 
            this.lblPrecoGas.AutoSize = true;
            this.lblPrecoGas.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoGas.Location = new System.Drawing.Point(241, 111);
            this.lblPrecoGas.Name = "lblPrecoGas";
            this.lblPrecoGas.Size = new System.Drawing.Size(168, 28);
            this.lblPrecoGas.TabIndex = 5;
            this.lblPrecoGas.Text = "Preço Gasolina:";
            // 
            // pnlCabecario
            // 
            this.pnlCabecario.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlCabecario.Controls.Add(this.lblTitle);
            this.pnlCabecario.Location = new System.Drawing.Point(2, 1);
            this.pnlCabecario.Name = "pnlCabecario";
            this.pnlCabecario.Size = new System.Drawing.Size(808, 137);
            this.pnlCabecario.TabIndex = 10;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(213, 34);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(392, 45);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "PREÇO GASOLINA";
            // 
            // pnlRodape
            // 
            this.pnlRodape.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlRodape.Location = new System.Drawing.Point(0, 434);
            this.pnlRodape.Name = "pnlRodape";
            this.pnlRodape.Size = new System.Drawing.Size(815, 21);
            this.pnlRodape.TabIndex = 11;
            this.pnlRodape.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 450);
            this.Controls.Add(this.pnlRodape);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPago);
            this.Controls.Add(this.txtGas);
            this.Controls.Add(this.lblPago);
            this.Controls.Add(this.lblPrecoGas);
            this.Controls.Add(this.pnlCabecario);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.pnlCabecario.ResumeLayout(false);
            this.pnlCabecario.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.TextBox txtGas;
        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.Label lblPrecoGas;
        private System.Windows.Forms.Panel pnlCabecario;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlRodape;
    }
}