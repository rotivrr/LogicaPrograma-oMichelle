﻿namespace Precogas
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrecoGas = new System.Windows.Forms.Label();
            this.lblPago = new System.Windows.Forms.Label();
            this.txtGas = new System.Windows.Forms.TextBox();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrecoGas
            // 
            this.lblPrecoGas.AutoSize = true;
            this.lblPrecoGas.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoGas.Location = new System.Drawing.Point(5, 72);
            this.lblPrecoGas.Name = "lblPrecoGas";
            this.lblPrecoGas.Size = new System.Drawing.Size(168, 28);
            this.lblPrecoGas.TabIndex = 0;
            this.lblPrecoGas.Text = "Preço Gasolina:";
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPago.Location = new System.Drawing.Point(4, 146);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(144, 31);
            this.lblPago.TabIndex = 1;
            this.lblPago.Text = "Valor Pago:";
            // 
            // txtGas
            // 
            this.txtGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGas.Location = new System.Drawing.Point(179, 72);
            this.txtGas.Name = "txtGas";
            this.txtGas.Size = new System.Drawing.Size(143, 31);
            this.txtGas.TabIndex = 2;
            this.txtGas.TextChanged += new System.EventHandler(this.txtGas_TextChanged);
            // 
            // txtPago
            // 
            this.txtPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPago.Location = new System.Drawing.Point(179, 149);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(143, 31);
            this.txtPago.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(91, 218);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(171, 59);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseCompatibleTextRendering = true;
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.UseWaitCursor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPago);
            this.Controls.Add(this.txtGas);
            this.Controls.Add(this.lblPago);
            this.Controls.Add(this.lblPrecoGas);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrecoGas;
        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.TextBox txtGas;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.Button btnCalcular;
    }
}

