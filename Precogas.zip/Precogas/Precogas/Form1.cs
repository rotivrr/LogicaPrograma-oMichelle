﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Precogas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtGas_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float varGas = float.Parse(txtGas.Text);
            float varpreco = float.Parse(txtPago.Text);
            float resultado = varpreco / varGas;
            MessageBox.Show ("O usuário abasteceu " +  resultado + " litros no total");
        }
    }
}
